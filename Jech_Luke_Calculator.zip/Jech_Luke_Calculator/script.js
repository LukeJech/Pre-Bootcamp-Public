var display = document.getElementById("display")
var value1 = 0
var value2 = 0
var operator = 0

function press(num) {
    if (operator == 0) {
        if (display.innerText == 0 ) {
            display.innerText = num
            value1 = display.innerText
        } else {
            display.innerText += num
            value1 = display.innerText
        }
    } else {
        if (value2 == 0) {
            display.innerText = num
            value2 = display.innerText
        } else {
            display.innerText += num
            value2 = display.innerText
        }
    }
}

function setOP (op) {
    operator = op
    console.log(operator)
}

function calculate () {
    if (operator == "+") {
        display.innerText = Number(value1) + Number(value2)
    } else if (operator == "-") {
        display.innerText = Number(value1) - Number(value2)
    } else if (operator == "/") {
        display.innerText = Number(value1) / Number(value2)
    } else if (operator == "*") {
        display.innerText = Number(value1) * Number(value2)
    }
    value1 = display.innerText
    value2 = 0
    operator = 0
}

function clr() {
    var value1 = 0
    var value2 = 0
    var operator = 0
    display.innerText = 0 
}