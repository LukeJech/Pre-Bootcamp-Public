// MVP
// As a diligent student, I want to reward myself if I finish my homework, and based on the time of day:

// I want a latte if it's before 10 am
// I want a hot chocolate it's between 10 am and 4 pm
// I want ice cream between 4 pm - 10 pm.
// If it's after 10 pm, I don't want anything other than sleep!

// Feature 1
// Building off the MVP, if I'm up for ice cream, I want strawberry - but only if it's Wednesday. Otherwise, I want vanilla.

// Feature 2 (hard) - Optional
// Building off Feature 1, I want to adjust the current conditions and add a new option so that if the time is between 3 pm - 6 pm, 
// I want to have it pick either ice cream or hot chocolate depending on if the time is even or odd.

// Feature 3 (super hard) - Optional
// Building off Feature 2, I want my options for the 3 pm - 6 pm slot to be a random 
// selection: if the time is even, I want my selections to be ice cream, cookies, or candy. 
// If the time is odd, I want my selections to be hot chocolate, tea, or cake.

function finish_HW(time,day) {
    // time is a 24 hour clock. ex 16 = 4pm
    
    let random_food_even = ["ice cream", "cookies", "candy"]
    let random_food_odd = ["hot chocolate", "tea", "cake"]

    if (time < 10) {
        return "latte"
    } else if ( time <= 15) {
        return "hot chocolate"
    } else if (time > 15 && time <= 18) {
        // feature 2 and 3 random selection of food based on time being odd or even
        let random_num = Math.floor(Math.random() * 3)
        if (time % 2 == 0 ) {
            return random_food_even[random_num]
        } else {
            return random_food_odd[random_num]
        }
    } else if ( time <= 22) {
        // if it's wednesday ice cream will be strawberry instead of vanilla
        if (day.toUpperCase() == "WEDNESDAY") {
            return "strawberry ice cream"   
        } else {return "vanilla ice cream"}
    } else {
        return "time to sleep!"
    }
}

console.log(finish_HW(18,"Wednesday"))
console.log(finish_HW(17,"Wednesday"))
console.log(finish_HW(5,"tuesday"))
console.log(finish_HW(12,"tuesday"))
console.log(finish_HW(20,"monday"))
console.log(finish_HW(23,"monday"))