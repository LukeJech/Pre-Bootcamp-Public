console.log("page loaded...");

function play_video(element) {
    element.play()
}

function pause_video(element) {
    element.pause()
}