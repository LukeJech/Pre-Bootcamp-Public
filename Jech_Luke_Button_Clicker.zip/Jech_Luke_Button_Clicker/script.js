function login_out(element) {
    console.log(element.innerText)
    if (element.innerText == "Login") {
        element.innerText = "Log out"
    } else {
        element.innerText = "Login"
    }
}

function hide(element) {
    element.remove()
}

function addLike() {
    let likes = Number(counter_like1.innerHTML)
    likes += 1
    counter_like1.innerHTML = likes
}

function addLike2() {
    let likes = Number(counter_like2.innerHTML)
    likes += 1
    counter_like2.innerHTML = likes
}

const button_likes1 = document.querySelector("#button_like1")
const counter_like1 = document.querySelector("#likes1")

const button_likes2 = document.querySelector("#button_like2")
const counter_like2 = document.querySelector("#likes2")

button_likes1.onclick = addLike
button_likes2.onclick = addLike2