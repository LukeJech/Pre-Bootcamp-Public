const crusts = ["deep dish", "hand tossed", "stuffed crust"]
const sauces = ["marinaria", "white", "pesto"]
const cheeses = ["mozzarella", "4 cheese blend", "goat cheese", "cheddar?"]
const toppings = ["peppers", "olives", "spinach", "garlic", "pepperoni", "sausage", "bacon", "pickles"]


function makePizza (crustType, sauceType, cheeses, toppings) {
    var pizza = {}
    pizza.crust = crustType
    pizza.sauce = sauceType
    pizza.cheese =cheeses
    pizza.toppings = toppings
    
    return pizza
}

function randomPizza () {
    var pizza = {}
    pizza.crust = crusts[Math.floor(Math.random() * 3)]
    pizza.sauce = sauces[Math.floor(Math.random() * 3)]
    pizza.cheese =  cheeses[Math.floor(Math.random() * 4)]
    let pizza_toppings = []
    let toppings_amount = Math.floor(Math.random() * 4)
    for(let i = 0; i <= toppings_amount; i++) {
        pizza_toppings.push(toppings[Math.floor(Math.random() * 8)])
    }
    pizza.toppings = pizza_toppings
    
    return pizza
}

var pizza1 = makePizza("deep dish", "traditional", ["mozzarella"], ["pepperoni", "sausage"] )
console.log(pizza1)

var pizza2 = makePizza("hand tossed", "marinara", ["mozzarella", "feta"],["mushrooms", "olives", "onions"])
console.log(pizza2)

var pizza3 = randomPizza()
console.log(pizza3)
console.log(pizza3.toppings)
// Create a pizza with: "deep dish", "traditional", ["mozzarella"], and ["pepperoni", "sausage"]

// Create a pizza with: "hand tossed", "marinara", ["mozzarella", "feta"], and ["mushrooms", "olives", "onions"]

// Create 2 more pizzas with any toppings we like!

class Pizza {
    constructor(crust, sauce, cheeses, toppings) {
        this.crust = crust 
        this.sauce = sauce
        this.cheese = cheeses
        this.toppings = toppings
    }

    eat() {
        console.log(`You take a delicious bite of your ${this.sauce} ${this.cheese[0]} Pizza. Enjoy!`)
    }
}

const pizza4 = new Pizza("breadstick crust", "pesto", [cheeses[0], cheeses[2]], [toppings[3], toppings[6]])

console.log(pizza4)
console.log(pizza4.cheese)
console.log(pizza4.toppings)

pizza4.eat()